function sayhello()
{
document.write("Hello World");
}