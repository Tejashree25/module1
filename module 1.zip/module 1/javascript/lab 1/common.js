function addNos(headVar,bodyVar)
{
var add=headVar+bodyVar;
document.write(add);
}